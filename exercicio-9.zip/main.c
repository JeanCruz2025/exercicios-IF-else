/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float nota1, nota2 , soma, media;
    
    printf("CALCULO DE MEDIA \n");
    printf ("Digite a nota 1\n");
    scanf ("%f",&nota1);
    
    printf("Digite a nota 2\n");
    scanf ("%f", &nota2);
    
    media = (nota1 + nota2) /2;
    
    if (media >= 6) {
      printf  ("Aluno Aprovado \n");
    } else if (media  >= 4 ) {
      printf  ("Aluno de Recuperação\n");
    } else {
      printf  ("Aluno Reprovado\n");
    }
      printf  ("O valor da Média é: %.1f",media);
    }

